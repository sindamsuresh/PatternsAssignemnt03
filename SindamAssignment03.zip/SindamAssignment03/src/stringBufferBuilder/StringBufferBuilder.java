package stringBufferBuilder;

public class StringBufferBuilder {

	public static void main(String[] args) {
		StringBuffer bufferObj=new StringBuffer("Hello");  
        bufferObj.append("World");  
        System.out.println(bufferObj);  
        System.out.println(System.nanoTime());
        
        StringBuilder builderObj=new StringBuilder("Hello");  
        builderObj.append("World");  
        System.out.println(builderObj);  
        System.out.println(System.nanoTime());
	}

}
