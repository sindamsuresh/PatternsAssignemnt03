package GenericDemo;



public class GenericDemoDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		GenericDemoClass<String> str = new GenericDemoClass<>("Hello, world!");
		GenericDemoClass<Integer> intValue = new GenericDemoClass<>(24);
	      
		System.out.println(str.getData());
		System.out.println(intValue.getData());
	}

}
