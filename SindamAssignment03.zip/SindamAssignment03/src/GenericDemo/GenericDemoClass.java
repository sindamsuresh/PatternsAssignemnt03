package GenericDemo;

public class GenericDemoClass<Z> {
	private Z data;

    public void setData(Z data) {
        this. data = data;
    }

    public Z getData() {
        return data;
    }
}

