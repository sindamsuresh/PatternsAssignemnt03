package vectorarraylist;

import java.util.ArrayList;
import java.util.Vector;

public class VectorVsArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Create a Vector and an ArrayList
        Vector<String> vector = new Vector<>();
        ArrayList<String> arrayList = new ArrayList<>();

        // Add elements to both collections
        vector.add("apple");
        arrayList.add("apple");
        vector.add("banana");
        arrayList.add("banana");

        // Iterate over the collections using a for-each loop
        for (String fruit : vector) {
            System.out.println(fruit);
        }
        for (String fruit : arrayList) {
            System.out.println(fruit);
        }

	}

}
