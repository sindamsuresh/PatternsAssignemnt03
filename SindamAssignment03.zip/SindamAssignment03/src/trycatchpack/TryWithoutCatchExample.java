package trycatchpack;

public class TryWithoutCatchExample {
    public static void main(String[] args) {
        try {
            // some code that may throw an exception
            System.out.println("try block inside.");
            int x = 1/0; // This will throw an ArithmeticException
        } finally {
            // code that will always be executed, whether an exception is thrown or not
            System.out.println("finally block inside.");
        }
        // program execution continues here
    }
}

