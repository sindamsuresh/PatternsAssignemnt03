package immutable;

public class StrImmutable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Hello";
		str.concat(" World");
		System.out.println(str); // Output: "Hello"

	}

}
