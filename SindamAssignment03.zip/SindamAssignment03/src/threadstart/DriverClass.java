package threadstart;



public class DriverClass extends Thread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DriverClass t1 = new DriverClass();

        t1.start(); // 1st thread is started

        try {
            t1.join(); // Wait for thread to finish
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // will get an IllegalThreadStateException
        t1.start(); // 2nd therad started - will throw an exception
	}
	
	public void run() {
        System.out.println("Thread is running...");
    }

}
