package finalfinallyfinalize;


public class DriverClass {

	public static void main(String[] args) throws Throwable {
		// TODO Auto-generated method stub
		final int a=10;
		System.out.println(a);
		DriverClass d= new DriverClass();
		d.finalize();
	}


	protected void finalize() throws Throwable { 
		try {
			System.out.println("This is try Block");
		}
		finally {
			System.out.println("This is finally block");
		}
	}
}
