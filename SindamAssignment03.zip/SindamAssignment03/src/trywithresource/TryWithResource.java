package trywithresource;

import java.io.FileInputStream;
import java.io.IOException;

public class TryWithResource {
	public static void main(String[] args) {
		try (FileInputStream input = new FileInputStream("myfile.txt")) {
		    // read data from the file
		} catch (IOException e) {
		    // handle the exception
			// not added file to get the error 
			System.out.println("No file found");
		}
	}
}
