package finalconstructor;

public class FinalConstructor {
	
	//if we write constructor as final we will get Illegal modifier for the constructor in type FinalConstructor; 
	//only public, protected & private are permitted error
	
//	public final FinalConstructor() {
//		
//	}

}
