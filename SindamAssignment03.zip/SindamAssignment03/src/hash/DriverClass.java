package hash;

import java.util.HashMap;
import java.util.Hashtable;

public class DriverClass {

	public static void main(String[] args) {
		System.out.println("Using HashMap");
		Hashtable<String, Integer> cricMap = new Hashtable<>();
		cricMap.put("MSDhoni", 41);
		cricMap.put("Yuvaraj", 40);
		cricMap.put("Raina", 39);

		for (String name : cricMap.keySet()) {
			int age = cricMap.get(name);
			System.out.println(name + "'s age is: " + age);
		}
		System.out.println("Using HashMap");
		HashMap<String, Integer> Cricketer = new HashMap<>();
		Cricketer.put("MSDhoni", 41);
		Cricketer.put("Yuvaraj", 40);
		Cricketer.put("Raina", 39);

		for (String name : Cricketer.keySet()) {
			int age = Cricketer.get(name);
			System.out.println(name + "'s age is: " + age);
		}

	}

}
