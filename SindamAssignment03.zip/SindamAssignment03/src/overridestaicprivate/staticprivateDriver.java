package overridestaicprivate;



public class staticprivateDriver {
	public static void main(String[] args) {
		//staicprivate1.privateMethod(); // we can't access private method
		staicprivate1.publicMethod(); 
	}
}
