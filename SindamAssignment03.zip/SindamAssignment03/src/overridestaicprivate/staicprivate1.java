package overridestaicprivate;

public class staicprivate1 {
	private static void privateMethod() {
        System.out.println("Superclass private method");
    }
    
    public static void publicMethod() {
        System.out.println("Superclass public method");
    }
    
//    private static void privateMethod1() {
//        System.out.println("This is a private method in subclass.");
//    }
//    
//    
//    public static void publicMethod1() {
//        System.out.println("This is a public method in subclass.");
//    }
}
