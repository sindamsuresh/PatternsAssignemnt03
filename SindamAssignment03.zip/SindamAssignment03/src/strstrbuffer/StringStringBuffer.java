package strstrbuffer;

public class StringStringBuffer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1 = "Suresh";
        String str2 =  "Sindam"+str1;
        System.out.println(str2);
        System.out.println(System.nanoTime());
        
        StringBuffer buffer=new StringBuffer("Hello");  
        buffer.append("World");  
        System.out.println(buffer);  
        System.out.println(System.nanoTime());
	}

}
