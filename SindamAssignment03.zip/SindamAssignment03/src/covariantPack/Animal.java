package covariantPack;


class Animal {
	   public Animal getAnimal() {
		   System.out.println("From Animal Class");
	      return new Animal();
	   }
	}

	class Dog extends Animal {
	   @Override
	   public Dog getAnimal() {
		   System.out.println("From Dog Class");
	      return new Dog();
	   }
	}

