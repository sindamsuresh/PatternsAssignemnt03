package covariantPack;

public class AnimalDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	      Animal animal = new Animal();
	      Dog dog = new Dog();
	      
	      Animal animal1 = dog.getAnimal(); // returns Dog object as Animal
	      Dog dog1 = dog.getAnimal(); // returns Dog object as Dog

	}

}
