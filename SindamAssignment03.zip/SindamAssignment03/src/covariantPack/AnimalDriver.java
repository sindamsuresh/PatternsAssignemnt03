package covariantPack;

public class AnimalDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	      Animal animal = new Animal();
	      Dog dog = new Dog();
	      
	      Animal animal1 = animal.getAnimal(); // returns Dog object as Animal
	      Animal dog1 = dog.getAnimal(); // returns Dog object as Dog
	}

}
