package failfastsafe;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class DriverClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> listObj = new CopyOnWriteArrayList<>();
		listObj.add(100);
		listObj.add(101);
		listObj.add(103);

		Iterator<Integer> itr = listObj.iterator();

		while (itr.hasNext()) {
		    Integer value = itr.next();
		    System.out.println(value);
		    listObj.remove(value);
		}
		List<Integer> l = new ArrayList<>();
		l.add(11);
		l.add(22);
		l.add(33);

		Iterator<Integer> itr1 = l.iterator();

		while (itr1.hasNext()) {
		    Integer value = itr1.next();
		    System.out.println(value);
		    l.remove(value); // modification during iteration
		}
	}

}
