package supersubclass;

import java.io.FileNotFoundException;
import java.io.IOException;


public class SuperClass {
	public void method1() throws IOException {
        System.out.println("super class");
    }
}


class SubClass extends SuperClass {
    public void method1() throws FileNotFoundException {
        System.out.println("sub class");
    }
}