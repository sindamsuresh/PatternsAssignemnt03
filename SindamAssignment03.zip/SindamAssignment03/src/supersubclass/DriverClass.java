package supersubclass;

import java.io.IOException;

public class DriverClass {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		SuperClass superClass = new SuperClass();
        SubClass subClass = new SubClass();
        
        try {
            superClass.method1();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        try {
            subClass.method1();
        } finally {
        	System.out.println("This is finally block");
        }
	}

}
