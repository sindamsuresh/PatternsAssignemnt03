package createthread;

public class MyThread extends Thread  {
	public void run() {
        // Thread behavior goes here
		System.out.println("MyThread running.");
    }

	public void start() {
		// TODO Auto-generated method stub
		System.out.println("MyThread started.");
	}
}
