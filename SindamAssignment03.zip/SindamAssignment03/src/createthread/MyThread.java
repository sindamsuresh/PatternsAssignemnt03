package createthread;

public class MyThread extends Thread  {
	public void run() {
        // Thread behavior goes here
    }

	public void start() {
		// TODO Auto-generated method stub
		
	}
}
