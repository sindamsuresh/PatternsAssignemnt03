package createthread;

public class ThreadDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Creating and starting the thread
		MyThread thread = new MyThread();
		thread.start();

	}

}
