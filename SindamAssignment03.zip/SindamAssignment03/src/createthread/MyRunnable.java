package createthread;

public class MyRunnable implements Runnable  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyRunnable myRunnable = new MyRunnable();
		Thread thread = new Thread(myRunnable);
		thread.start();

	}
	
	public void run() {
		System.out.println("MyRunnable is running.");
        // Thread behavior goes here
    }


}
